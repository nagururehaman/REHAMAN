import UIKit

var greeting = "Hello, playground"

print("hii",11,12.35)

//var name = "Ajay"
//var grade = "B"
//print("Hello,\(name)! You got the \(grade) in ios course.")


var age = 24
print("your age is \(age) and when you tripled your age will be \(age * 3)")

print("""
Hello
world!
dsjfhas; sjkasdcd;
sdwefnj
sdc
wc
""")

print ("Hello All,\rWelcome to Swift programming")

let mymessage : String = "Hows your day"
print(mymessage,"everyone")



print("Welcome to Swift Programming")
print("Fall 2021")
//print(*****************)
print("Welcome to Swift Programming", terminator: "-")
print("spring 2022")


var name = "Rehaman"
var grade = 4.0
print("Hello,\(name)! You got the \(grade) in ios course.", terminator:"$")


print("The list of numbers are")
print(71,73,75,77,79)
print("The new pattern is")
print(71,73,75,77,79, separator: "#")

//Constants and variables

var myname = "rehaman"
myname="naguru"
print(myname)

let myhands = 2
//myhands = 3 //Cannot assign to value: 'myhands' is a 'let' constant
print(myhands, terminator: "%")
print("End")

var myage : Int = 24
myage = myage*2
print(age)

var message = "this is my message"
print(message)
print("message")

var sub1 = "java"
var sub2 = "ios"
print(sub1,sub2)
print(sub1,"$",sub2)


print(10,20,30)
print(12.5,15.5)


//Tuples

var daily = (item1 : "keys" , item2 : "purse")
print(daily)
print(daily.item1 , terminator: "^")
print(daily.item2)


var names = ("rehaman","naguru")
var fname = names.0
var lname = names.1
print(fname, terminator: "*")
print(lname)


var origin = (x : 0 , y : 0)
var point = origin
print(point)


let city = (name : "Maryville" , population : 11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

let groceries = ("milk","eggs")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var firstname = "Joe"
var lastname = "Root"
(firstname , lastname) = (lastname , firstname)
print("First Name is \(firstname) and Last Name is \(lastname)")


var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
