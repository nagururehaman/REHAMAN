//
//  Constant.swift
//  Patronage
//
//  Created by Naguru Abdur,Rehaman on 4/29/22.
//

import Foundation


let app_id = "49E20D38-48BC-655F-FF0A-BD4C613C6600"
let rest_key = "C6F9FBB8-0A33-4040-9D6D-427BF495283D"
let base_url = "https://api.backendless.com/\(app_id)/\(rest_key)/users/"
let register_url = "\(base_url)register"
let login_url = "\(base_url)login"

let app_id2 = "7C9EF361-2601-CEBC-FF02-1235BEA79300"
let rest_key2 = "64B97751-483B-4492-9F24-2E7C69D746FD"
let base_url2 = "https://api.backendless.com/\(app_id2)/\(rest_key2)/users/"
let product_url = "\(base_url2)register"
